package queues;

import java.util.*;

public class QueueMain {

	public static void main(String[] args) {
		// This QueueMain instantiates a queue
		FIFOQImpl q = new FIFOQImpl();
		

	}

}
